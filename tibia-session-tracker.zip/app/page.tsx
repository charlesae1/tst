"use client"

import { useState } from "react"

export default function Home() {
  const [text, setText] = useState("")

  async function save() {
    const response = await fetch("/api/save-session", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ text }),
    })

    const data = await response.json()

    alert(
      `Sessão salva! RAW XP: ${data.parsed.rawXpGain} | XP: ${data.parsed.xpGain}`
    )

    setText("")
  }

  return (
    <main style={{ padding: 20, fontFamily: "Arial" }}>
      <h1>Tibia Session Tracker</h1>

      <textarea
        style={{
          width: "100%",
          height: 300,
          padding: 10,
          marginTop: 20
        }}
        placeholder="Cole aqui o hunting analyser"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />

      <button
        onClick={save}
        style={{
          marginTop: 20,
          padding: "12px 20px",
          background: "green",
          color: "white",
          border: 0,
          cursor: "pointer"
        }}
      >
        Salvar Sessão
      </button>
    </main>
  )
}